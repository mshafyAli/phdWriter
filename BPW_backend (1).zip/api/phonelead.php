<?php
// Allow CORS
header('Access-Control-Allow-Origin: https://academians.com.au'); // Update this to match your frontend origin
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true'); // Optional: Allows cookies to be sent
header('Content-Type: application/json');

// Handle preflight requests for CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Include your database configuration
include_once '../config/database.php';

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

// Fetch the JSON input
$data = json_decode(file_get_contents("php://input"));

if (empty($data->number)) {
    http_response_code(400);
    echo json_encode(["message" => "Missing required fields"]);
    exit;
}

$number = $connection->real_escape_string($data->number);

// Insert the phone number into the database
$query = "INSERT INTO phoneleads (number) VALUES ('$number')";
if ($connection->query($query) === TRUE) {
    // Send an email with the signup details
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true;
        $mail->Username   = 'engrsyedusamaakhtar@gmail.com'; // SMTP username
        $mail->Password   = 'ooxh lnul vmvy nuro'; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption; PHPMailer::ENCRYPTION_SMTPS for SSL
        $mail->Port       = 587; // TCP port to connect to

        // Recipients
        $mail->setFrom('engrsyedusamaakhtar@gmail.com', 'Encoders'); // Replace with your sender email and name
        $mail->addAddress('engrsyedusamaakhtar@gmail.com'); // Add the recipient email address

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = 'PHONE LEAD - ACADEMIANS AUSTRALIA';
        $mail->Body    = "
            <h2>YOU HAVE A PHONE LEAD ON ACADEMIANS AUSTRALIA PTY LTD</h2>
             <h3>www.academians.com.au</h3>
         
            <p><strong>Phone Number:</strong> {$number}</p>
        
        ";

        $mail->send();
        http_response_code(201); // Created
        echo json_encode(["message" => "PhoneLead created and email sent with details!"]);
    } catch (Exception $e) {
        http_response_code(500); // Internal server error
        echo json_encode(["message" => "PhoneLead created but email sending failed", "error" => $mail->ErrorInfo]);
    }
} else {
    http_response_code(500);
    echo json_encode(["message" => "Error creating phone lead", "error" => $connection->error]);
}

$connection->close();
?>
