<?php
// Disable caching by setting appropriate headers
header('Expires: Tue, 01 Jan 2000 00:00:00 GMT'); // Expired in the past
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // Last modified now
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); // HTTP/1.1
header('Cache-Control: post-check=0, pre-check=0', false); // HTTP/1.1 for IE-specific options
header('Pragma: no-cache'); // HTTP/1.0

// Allow cross-origin requests from specific origin
// List of allowed origins
$allowed_origins = [
    'https://www.britishphdwriters.co.uk',
    'https://britishphdwriters.co.uk'
];

// Check the origin of the incoming request
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // If the origin is in the allowed origins, set the CORS header
    if (in_array($_SERVER['HTTP_ORIGIN'], $allowed_origins)) {
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
    }
}
header('Access-Control-Allow-Methods: GET, OPTIONS'); 
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With'); 
header('Content-Type: application/json'); 
header('Access-Control-Allow-Credentials: true'); 

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Include database configuration
include_once '../config/database.php';

// Validate the database connection
if (!isset($connection) || !$connection instanceof mysqli) {
    echo json_encode(["message" => "Database connection not established"]);
    exit;
}

if ($connection->connect_error) {
    echo json_encode(["message" => "Database connection failed", "error" => $connection->connect_error]);
    exit;
}

// Query to get the last order number
$sql = "SELECT order_number FROM Bpw_order_now ORDER BY id DESC LIMIT 1";
$result = $connection->query($sql);

$newOrderNumber = 'BPW-6000'; // Default starting order number

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $lastOrderNumber = $row['order_number'];
    
    // Extract and increment the numeric part of the order number
    $orderNumberParts = explode('-', $lastOrderNumber);
    $orderNumberPart = isset($orderNumberParts[1]) ? (int)$orderNumberParts[1] : 6000;
    $newNumberPart = $orderNumberPart + 1;
    $newOrderNumber = "BPW-" . $newNumberPart;
}

// Check if the request is to create a new order
if (isset($_GET['create_order']) && $_GET['create_order'] == 'true') {
    // Insert the new order number back into the database
    $insertSql = "INSERT INTO Bpw_order_now (order_number) VALUES ('$newOrderNumber')";
    if ($connection->query($insertSql) === TRUE) {
        // Return the new order number as JSON
        echo json_encode(['order_number' => $newOrderNumber]);
    } else {
        echo json_encode(["message" => "Error saving new order number", "error" => $connection->error]);
    }
} else {
    // Just return the new order number without inserting
    echo json_encode(['order_number' => $newOrderNumber]);
}

// Close the database connection
$connection->close();
?>
