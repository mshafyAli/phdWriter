<?php
// Include the header file
// List of allowed origins
$allowed_origins = [
    'https://www.britishphdwriters.co.uk',
    'https://britishphdwriters.co.uk'
];

// Check the origin of the incoming request
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // If the origin is in the allowed origins, set the CORS header
    if (in_array($_SERVER['HTTP_ORIGIN'], $allowed_origins)) {
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
    }
}


header('Access-Control-Allow-Methods: POST, OPTIONS'); // Allow methods
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With'); // Allow headers
header('Content-Type: application/json'); // Set content type to JSON
header('Access-Control-Allow-Credentials: true'); // Optional: Allows cookies to be sent

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200); // OK for preflight
    exit;
}

// Include database configuration
include_once '../config/database.php';

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

// Check if $connection is set correctly and is an instance of the mysqli class
if (!isset($connection) || !$connection instanceof mysqli) {
    echo json_encode(["message" => "Database connection not established"]);
    exit;
}

// Further checking if connection has errors
if ($connection->connect_error) {
    echo json_encode(["message" => "Database connection failed", "error" => $connection->connect_error]);
    exit;
}

// Handle POST request for creating a new order
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if content type is JSON
    if (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        // Get raw POST data
        $data = json_decode(file_get_contents('php://input'), true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['message' => 'Invalid JSON']);
            http_response_code(400);
            exit;
        }
        
        $name = $data['name'] ?? null;
        $email = $data['email'] ?? null;
        $phone = $data['phone'] ?? null;
        $total_amount = $data['total_amount'] ?? null;
    } else {
        // Handle form-urlencoded data
        $name = $_POST['name'] ?? null;
        $email = $_POST['email'] ?? null;
        $phone = $_POST['phone'] ?? null;
        $total_amount = $_POST['total_amount'] ?? null;
    }

    // Validate required fields
    if (empty($name) || empty($email) || empty($phone) || empty($total_amount)) {
        echo json_encode(['message' => 'Missing required fields']);
        http_response_code(400);
        exit;
    }

    // Fetch the last order number
    $getLastOrderNumberQuery = "SELECT order_number FROM Bpw_order_now ORDER BY id DESC LIMIT 1";
    $result = $connection->query($getLastOrderNumberQuery);

    $newOrderNumber = 'BPW-6000'; // Default starting order number

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastOrderNumber = $row['order_number'];

        // Extract numeric part from the last order number
        $orderNumberPart = (int)substr($lastOrderNumber, 4);

        // Debugging: Log the last order number and part
        error_log("Last Order Number: $lastOrderNumber");
        error_log("Order Number Part: $orderNumberPart");

        if (!is_numeric($orderNumberPart)) {
            echo json_encode(['message' => 'Invalid last order number format']);
            http_response_code(500);
            exit;
        }

        // Increment the order number by 1
        $newNumberPart = $orderNumberPart + 1;
        $newOrderNumber = "BPW-$newNumberPart";

        // Debugging: Log the new order number
        error_log("New Order Number: $newOrderNumber");
    }

    // Insert new order
    $insertOrderQuery = "INSERT INTO Bpw_order_now (name, email, phone, order_number, total_amount) VALUES (?, ?, ?, ?, ?)";
    $stmt = $connection->prepare($insertOrderQuery);
    $stmt->bind_param("ssssd", $name, $email, $phone, $newOrderNumber, $total_amount);

    if ($stmt->execute()) {
        // Set up PHPMailer
        $mail = new PHPMailer(true);
        
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
            $mail->SMTPAuth   = true;
            $mail->Username   = 'engrsyedusamaakhtar@gmail.com'; // SMTP username
            $mail->Password   = 'ooxh lnul vmvy nuro'; // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port       = 587; // TCP port to connect to

            // Recipients
            $mail->setFrom('engrsyedusamaakhtar@gmail.com', 'Encoders');
            $mail->addAddress('engrsyedusamaakhtar@gmail.com');

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'ORDER - British Phd Writers';
            $mail->Body    = "
                 <h2>ORDER PLACED ON British Phd Writers</h2>
             <h3>www.britishphdwriters.co.uk</h3>
                <p><strong>Name:</strong> {$name}</p>
                <p><strong>Email:</strong> {$email}</p>
                <p><strong>Phone Number:</strong> {$phone}</p>
                <p><strong>Order Number:</strong> {$newOrderNumber}</p>
                <p><strong>Total Amount:</strong> {$total_amount}</p>
                
            ";

            $mail->send();
            http_response_code(201); // Created
            echo json_encode(["message" => "Order created and email sent with details!"]);
        } catch (Exception $e) {
            http_response_code(500); // Internal server error
            echo json_encode(["message" => "Order created but email sending failed", "error" => $mail->ErrorInfo]);
        }
    } else {
        http_response_code(500); // Internal server error
        echo json_encode(["message" => "Error creating order", "error" => $connection->error]);
    }

    $stmt->close();
}

$connection->close();
?>
