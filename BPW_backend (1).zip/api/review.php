<?php
$allowed_origins = [
    'https://www.britishphdwriters.co.uk',
    'https://britishphdwriters.co.uk'
];

// Check the origin of the incoming request
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // If the origin is in the allowed origins, set the CORS header
    if (in_array($_SERVER['HTTP_ORIGIN'], $allowed_origins)) {
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
    }
}



// Allow specific HTTP methods and headers
header('Access-Control-Allow-Methods: POST, OPTIONS'); // Allow methods
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With'); // Allow headers
header('Access-Control-Allow-Credentials: true'); // Allows cookies to be sent
header('Content-Type: application/json'); // Set content type to JSON

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Handle preflight requests
    http_response_code(200); // OK for preflight
    exit;
}



// Include database configuration
include_once '../config/database.php';

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

// Check if $connection is set correctly and is an instance of the mysqli class
if (!isset($connection) || !$connection instanceof mysqli) {
    echo json_encode(["message" => "Database connection not established"]);
    exit;
}

// Further checking if connection has errors
if ($connection->connect_error) {
    echo json_encode(["message" => "Database connection failed", "error" => $connection->connect_error]);
    exit;
}

// Get the posted data
$data = json_decode(file_get_contents("php://input"));

if (empty($data->name) || empty($data->email) || empty($data->phone)) {
    http_response_code(400); // Bad request
    echo json_encode(["message" => "Missing required fields"]);
    exit;
}

$name = $connection->real_escape_string($data->name);
$email = $connection->real_escape_string($data->email);
$phone = $connection->real_escape_string($data->phone);
$review = $connection->real_escape_string($data->review);


$query = "INSERT INTO reviews (name, email, phone, review) VALUES ('$name', '$email', '$phone','$review')";

if ($connection->query($query) === TRUE) {
    // Send an email with the signup details
    $mail = new PHPMailer(true);
    

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true;
        $mail->Username   = 'engrsyedusamaakhtar@gmail.com'; // SMTP username
        $mail->Password   = 'ooxh lnul vmvy nuro'; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption; PHPMailer::ENCRYPTION_SMTPS for SSL
        $mail->Port       = 587; // TCP port to connect to

        // Recipients
        $mail->setFrom('engrsyedusamaakhtar@gmail.com', 'Encoders'); // Replace with your sender email and name
        $mail->addAddress('engrsyedusamaakhtar@gmail.com'); // Add the recipient email address

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = 'Review - British Phd Writers';
        $mail->Body    = "
            <h2>YOU HAVE A REVIEW ON British Phd Writers</h2>
            <h3>www.britishphdwriters.co.uk</h3>
            <p><strong>Name:</strong> {$name}</p>
            <p><strong>Email:</strong> {$email}</p>
            <p><strong>Phone Number:</strong> {$phone}</p>
            <p><strong>Review:</strong> {$review}</p>

            
        ";

        $mail->send();
        http_response_code(201); // Created
        echo json_encode(["message" => "User created and email sent with details!"]);
    } catch (Exception $e) {
        http_response_code(500); // Internal server error
        echo json_encode(["message" => "User created but email sending failed", "error" => $mail->ErrorInfo]);
    }
} else {
    http_response_code(500); // Internal server error
    echo json_encode(["message" => "Error creating user", "error" => $connection->error]);
}

$connection->close();
?>
