

<?php
$servername = "35.214.34.114";
$username = "uarltfbqpgza6";
$password = "31ok2k[Gt182";
$dbname = "dbvpaugpgzugt1";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
} else {
    echo "Connected successfully"; 
}
?>
